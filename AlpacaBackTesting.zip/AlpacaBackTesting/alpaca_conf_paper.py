"""
Put secret Keys as environment variables
"""
import os

ALPACA_ENDPOINT = "https://paper-api.alpaca.markets"
ALPACA_KEYID = "PKJKN76RVLPBJSONE2GY"
ALPACA_SECRETKEY = "vk1hVUvdvUrmz9ebFQ2hzP9QTFxue2ZkRogadiPp"

os.environ["APCA_API_KEY_ID"] = ALPACA_KEYID
os.environ["APCA_API_SECRET_KEY"] = ALPACA_SECRETKEY
os.environ["APCA_API_BASE_URL"] = ALPACA_ENDPOINT