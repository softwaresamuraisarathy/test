import plotly.graph_objects as go
import os
os.environ['PLOTLY_RENDERER'] = 'browser'

fig = go.Figure(
    data=[go.Bar(y=[2, 1, 3])],
    layout_title_text="A Figure Displayed with the 'svg' Renderer"
)

#fig.show(renderer="browser")
fig.show()