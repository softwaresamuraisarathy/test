
from alpaca_trade_api.rest import DATA_V2_MAX_LIMIT
import config, requests, json,os
from datetime import datetime
import pandas as pd

symbol = 'AAPL'
str_from_date = '2021-01-01'
str_to_date = '2021-09-10'
limit = str(DATA_V2_MAX_LIMIT)
timeframe = '1Min'

daterange = pd.date_range(str_from_date, str_to_date)

filename = '../historical-market-data/{}-From-{}-To-{}.txt'.format(symbol,str_from_date,str_to_date)
if os.path.exists(filename):
    os.remove(filename)

f = open(filename, 'a')
f.write('Date,Open,High,Low,Close,Volume,OpenInterest\n')


for single_date in daterange:
    str_cur_date = single_date.strftime("%Y-%m-%d")

    str_start_cur_date_time = str_cur_date + 'T14:30:00Z'
    str_end_cur_date_time = str_cur_date + 'T21:00:00Z'

    minute_bars_url = config.BASE_URL_V2 + '/stocks/' + symbol + '/bars?start=' + str_start_cur_date_time + '&end=' + str_end_cur_date_time + '&limit=' + limit + '&timeframe=' + timeframe

    r = requests.get(minute_bars_url, headers=config.HEADERS)
    data = r.json()

    if data['bars'] is not None:        
        print('Writing ' + str(len(data['bars']))  + ' bars for ' + str_cur_date )
        for bar in data['bars']:
            line = '{},{},{},{},{},{},{}\n'.format(bar['t'], bar['o'], bar['h'], bar['l'], bar['c'], bar['v'], 0.00)
            f.write(line)
