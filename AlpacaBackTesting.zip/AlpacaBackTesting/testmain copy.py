import numpy as np
import pandas as pd
import cufflinks as cf
from plotly.offline import iplot, init_notebook_mode
import matplotlib.pyplot as plt
import os
import plotly.graph_objects as go

os.environ['PLOTLY_RENDERER'] = 'browser'
cf.go_offline()
init_notebook_mode()

TICKER = "AAPL"

filename = '../historical-market-data/{}.txt'.format(TICKER)

df = pd.read_csv(filename)

cf.set_config_file(theme='pearl', world_readable=False)
cf.go_offline()

qf = cf.QuantFig(df, title="Apple's stock price in 2021", name='AAPL')

                  ])
fig = go.Figure(data=[go.Candlestick(x=df['Date'],
                open=df['Open'], high=df['High'],
                low=df['Low'], close=df['Close'])
                     ])                     
fig.add_annotation(x='2021-09-01T14:30:00Z', y=154.73,
            text="Text annotation without arrow",
            showarrow=True,
            yshift=1)                     
fig.update_layout(xaxis_rangeslider_visible=False)

fig.show()
##############################################
#df = pd.read_csv('https://raw.githubusercontent.com/plotly/datasets/master/finance-charts-apple.csv')
#fig = go.Figure(data=[go.Candlestick(x=df['Date'],
#                open=df['AAPL.Open'], high=df['AAPL.High'],
#                low=df['AAPL.Low'], close=df['AAPL.Close'])
#   

#qf.add_sma([10, 50], width=2, color=['blue', 'red'])
#qf.add_rsi(periods=14, color='green')
#qf.add_bollinger_bands(periods=20, boll_std=2 ,colors=['orange','grey'], fill=True)
#qf.add_volume()
#qf.add_macd()
#qf.iplot(kind = 'candle', annotations=[{'text':'Manual annotation','x':1,'y':155,'xref':'paper','yref':'paper'}])