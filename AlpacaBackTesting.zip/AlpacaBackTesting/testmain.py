import numpy as np
import pandas as pd
import cufflinks as cf
from plotly.offline import iplot, init_notebook_mode
import matplotlib.pyplot as plt
import os
import plotly.graph_objects as go

os.environ['PLOTLY_RENDERER'] = 'browser'
cf.go_offline()
init_notebook_mode()

TICKER = "AAPL"
filename = '../historical-market-data/{}.txt'.format(TICKER)

df = pd.read_csv(filename)

fig = go.Figure(data=[go.Candlestick(x=df['Date'],
                open=df['Open'], high=df['High'],
                low=df['Low'], close=df['Close'])
                     ])    
fig.update_layout(xaxis_rangeslider_visible=False)

for i,r in df.iterrows():
    print(r['Open'])

fig.add_annotation(x='2021-09-01T14:30:00Z', y=154.73,
            text="Text annotation without arrow",
            showarrow=True,
            yshift=1)                     
fig.show(renderer='browser')
