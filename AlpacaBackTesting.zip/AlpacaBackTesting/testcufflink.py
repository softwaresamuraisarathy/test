import numpy as np
import pandas as pd
import yfinance as yf
import warnings



import cufflinks as cf
import plotly.graph_objects as go
from plotly.offline import iplot, init_notebook_mode
import matplotlib.pyplot as plt
import os

import plotly.io as pio
pio.renderers.default = "browser"
os.environ['PLOTLY_RENDERER'] = 'browser'


cf.go_offline()
#init_notebook_mode()

TICKER = "AAPL"

df = yf.download(TICKER, 
                 start="2021-01-01", 
                 end="2021-01-30")

layout1 = cf.Layout(
    height=300,
    width=200
)

cf.set_config_file(theme='pearl', world_readable=False)
cf.go_offline()



qf = cf.QuantFig(df, title="Apple's stock price in 2021", name='AAPL')


qf.iplot()
