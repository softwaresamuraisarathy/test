API_KEY = 'PKJKN76RVLPBJSONE2GY'
SECRET_KEY = 'vk1hVUvdvUrmz9ebFQ2hzP9QTFxue2ZkRogadiPp'
HEADERS = {
    'APCA-API-KEY-ID': API_KEY,
    'APCA-API-SECRET-KEY': SECRET_KEY
}
BARS_URL = 'https://data.alpaca.markets/v1/bars'
BASE_URL_V2 = 'https://data.alpaca.markets/v2'

