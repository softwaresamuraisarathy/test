import alpaca_trade_api as tradeapi

# authentication and connection details
api_key = 'PKJKN76RVLPBJSONE2GY'
api_secret = 'vk1hVUvdvUrmz9ebFQ2hzP9QTFxue2ZkRogadiPp'
base_url = 'https://paper-api.alpaca.markets'

# instantiate REST API
api = tradeapi.REST(api_key, api_secret, base_url, api_version='v2')

# obtain account information
account = api.get_account()
print(account)


