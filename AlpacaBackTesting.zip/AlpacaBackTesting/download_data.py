"""
Download historical minute by minute data for a symbol between a range of dates
"""
import os
from alpaca_trade_api.rest import DATA_V2_MAX_LIMIT, TimeFrame

import pandas as pd
from tqdm import tqdm

import alpaca_trade_api as tradeapi
import alpaca_conf_paper # loads API Keys as environment variables
from alpaca_trade_api.rest import REST


api = tradeapi.REST()
apirest = REST()

DATADIR = os.path.join('..', 'historical-market-data') # download directory for the data
SYMBOLS = ['AAPL']  # list of symbols we're interested
FROM_DATE = '2021-09-07'
TO_DATE = '2021-09-08'

# create data directory if it doesn't exist
if not os.path.exists(DATADIR):
    os.mkdir(DATADIR)

date_range = pd.date_range(FROM_DATE, TO_DATE)
for symbol in SYMBOLS:
    for fromdate in tqdm(date_range):
        if fromdate.dayofweek > 4:
            # it's a weekend
            continue

        _from = fromdate.strftime('%Y-%m-%d')
        _to = (fromdate + pd.Timedelta(days=1)).strftime('%Y-%m-%d')

        fname = f'{symbol}-{_from}.csv'  # for example, AAPL-2016-01-04.csv
        full_name = os.path.join(DATADIR, fname)
        if os.path.exists(full_name):
            # data file already exists, not necessary to download
            continue

        # download data as a pandas dataframe format
        
        df = api.get_bars(symbol=symbol, timeframe= TimeFrame.Minute, start=_from, end=_from, adjustment='raw',limit= DATA_V2_MAX_LIMIT).df
        print(df)

        if df.empty:
            tqdm.write(f'Error downloading data for date {_from}')
            continue

        # filter times in which the market in open
        print(df.columns)
        #df = df[df['vwap'].isin(pd.date_range(_from + ' 14:30:00', _to + ' 21:00:00'))]
        _from_time = _from + ' 14:30:00'
        _to_time = _to + ' 21:00:00'
        df.describe()
        #print(df['timestamp'].dtype)
        #df = df[(df['timestamp'] < _from_time) | (df['timestamp'] > _to_time )]
        df = df[df.timestamp.between(_from, _from)]
        #df = df.between_time(_from + ' 14:30:00', _from + ' 21:00:00')

        # saving csv for the data of the day in DATADIR/fname
        df.to_csv(full_name)
